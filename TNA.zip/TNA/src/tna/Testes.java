package tna;

import java.io.IOException;

public class Testes {

    //ATRIBUTOS
    private int entradaConvertida[];
    private int maximo;

    //MÉTODOS
    private void calculaMaximo() {
        for (int i = 0; i <= entradaConvertida.length - 1; i++) {
            if (maximo < entradaConvertida[i]) {
                maximo = entradaConvertida[i];
            }
        }
    }

//Construtor que executa chama o método de leitura e separa a string de números recebidos em um vetor
    public void construtorTestes() {
        String entrada = "1,2,4,56,6";
        try {
            entrada = Leitor.leitura();
        } catch (IOException | InterruptedException e) {
            System.out.println("Não deu");
        }
        String[] entradaSplit = entrada.split(",");
        entradaConvertida = new int[entradaSplit.length];
        for (int i = 0; i < entradaSplit.length; i++) {
            entradaConvertida[i] = Integer.parseInt(entradaSplit[i]);
        }
        calculaMaximo();
    }

//Cria o histograma necessário para se calcular o ChiQuadrado no vetor 'histograma'
    private int[] criaHistograma() {
        int[] histograma = new int[maximo];

        for (int j = 0; j <= entradaConvertida.length - 1; j++) {
            for (int i = 0; i <= maximo - 1; i++) {
                if (entradaConvertida[j] == i) {
                    histograma[i]++;
                }
            }
        }
        return histograma;
    }

//Realiza o cálculo do Chi-Quadrado
    public float calculaChiQuadrado() {
        float chiQuadrado = 0;
        float totalEsperado;

        totalEsperado = (float) (entradaConvertida.length) / (float) maximo;
        for (int i = 0; i <= criaHistograma().length - 1; i++) {
            chiQuadrado = chiQuadrado + ((((float) criaHistograma()[i] - totalEsperado) * ((float) criaHistograma()[i] - totalEsperado)) / totalEsperado);
        }
        Math.sqrt(chiQuadrado);
        return chiQuadrado;
    }

    public void calculaKS() {

        int[] numeros = new int[entradaConvertida.length]; // variavel de numeros
        int[] fao = new int[10]; // frequencia absoluta observada
        double[] fro = new double[10]; // frequencia relativa observada
        double[] freq = new double[10]; // frequencia acumulada observada 
        double[] fat = new double[10]; // frequencia acumulada teorica 
        double[] dfa = new double[10]; // diferenças frequencia acumulada
        double[] valorcritico = new double[10]; // resultado de valor critico

        //adicionando os numeros no vetor numeros (utilize essa variavel para colocar seus numeros)
        for (int i = 0; i <= entradaConvertida.length - 1; i++) {
            numeros[i] = entradaConvertida[i];
        }
        //adicionando o valor da frequencia acumulada teorica
        for(int i = 0; i <= 9; i++){
            if(i == 0){
                fat[i] = 0.1;
            } else {
                fat[i] = fat[i-1] + 0.1;
            }
        }
        //calculo de quantidade de numeros
        for (int i = 0; i <= entradaConvertida.length - 1; i++) {
            if(numeros[i] >= 0 && numeros[i] <= 25){
                fao[0]++;
                fro[0] = fao[0] / 1024.00;            
            }
            else if(numeros[i] >= 26 && numeros[i] <= 51){
                fao[1]++;
                fro[1] = fao[1] / 1024.00;
            } else if(numeros[i] >= 52 && numeros[i] <= 77){
                fao[2]++;
                fro[2] = fao[2] / 1024.00;
            } else if(numeros[i] >= 78 && numeros[i] <= 103){
                fao[3]++;
                fro[3] = fao[3] / 1024.00;
            } else if(numeros[i] >= 104 && numeros[i] <= 129){
                fao[4]++;
                fro[4] = fao[4] / 1024.00; 
            } else if(numeros[i] >= 130 && numeros[i] <= 155){
                fao[5]++;
                fro[5] = fao[5] / 1024.00; 
            } else if(numeros[i] >= 156 && numeros[i] <= 181){
                fao[6]++;
                fro[6] = fao[6] / 1024.00; 
            } else if(numeros[i] >= 182 && numeros[i] <= 207){
                fao[7]++;
                fro[7] = fao[7] / 1024.00;
            } else if(numeros[i] >= 208 && numeros[i] <= 233){
                fao[8]++;
                fro[8] = fao[8] / 1024.00;
            } else if(numeros[i] >= 234 && numeros[i] <= 255){
                fao[9]++;
                fro[9] = fao[9] / 1024.00; 
            }
            
            for(int j = 0; j <= 9; j++){
                if(j == 0){
                    freq[j] = fro[j]; 
                }else{
                    freq[j] = freq[j-1] + fro[j];
                }                
            }            
            for(int j = 0; j <= 9; j++){
                dfa[j] = freq[j] - fat[j];
            }
        }
        //for para imprimir a tabela. Recomendo que utilize-a antes de apagar ela do código, para ter total conhecimento sobre quais numeros utilizar, logo após pode apagar, pois nenhum valor é armazenado em tal.
        System.out.println("FAO -  FRO   -  FREQ  - FAT -   DFA    |   NUM");
        for (int i = 0; i <= 9; i++) {
            System.out.printf(" %d  - %.4f - %.4f - %.1f - %.4f", fao[i], fro[i], freq[i], fat[i], dfa[i]);
            switch (i) {
                case 0:
                    System.out.printf(" |  0 - 25");
                    break;
                case 1:
                    System.out.printf(" | 26 - 51");
                    break;
                case 2:
                    System.out.printf(" | 52 - 77");
                    break;
                case 3:
                    System.out.printf(" | 78 - 103");
                    break;
                case 4:
                    System.out.printf(" |104 - 129");
                    break;
                case 5:
                    System.out.printf(" |130 - 155");
                    break;
                case 6:
                    System.out.printf(" |156 - 181");  
                    break;
                case 7:
                    System.out.printf(" |182 - 207");
                    break;
                case 8:
                    System.out.printf(" |208 - 233");
                    break;
                case 9:
                    System.out.printf(" |234 - 255");
                    break;
                default:
                    break;
            }
            System.out.printf("\n");
        }
        //Cálculo do valor critico
        for (int i = 0; i <= 9; i++){
            valorcritico[i] = 1.36 / Math.sqrt(fao[i]);
        }
        
        //Impressão do resultado do cálculo do valor critico (veja a descrição da atualização de 24/06/2021 no github).
        for (int i = 0; i <= 9; i++) {
            switch (i) {
                case 0:
                    System.out.printf("O valor critico de 0 - 25 é: %.2f\n", valorcritico[i]);
                    break;
                case 1:
                    System.out.printf("O valor critico de 26 - 51 é: %.2f\n", valorcritico[i]);
                    break;
                case 2:
                    System.out.printf("O valor critico de 52 - 77 é: %.2f\n", valorcritico[i]);
                    break;
                case 3:
                    System.out.printf("O valor critico de 78 - 103 é: %.2f\n", valorcritico[i]);
                    break;
                case 4:
                    System.out.printf("O valor critico de 104 - 129 é: %.2f\n", valorcritico[i]);
                    break;
                case 5:
                    System.out.printf("O valor critico de 130 - 155 é: %.2f\n", valorcritico[i]);
                    break;
                case 6:
                    System.out.printf("O valor critico de 156 - 181 é: %.2f\n", valorcritico[i]);       
                    break;
                case 7:
                    System.out.printf("O valor critico de 182 - 207 é: %.2f\n", valorcritico[i]);
                    break;
                case 8:
                    System.out.printf("O valor critico de 208 - 233 é: %.2f\n", valorcritico[i]);
                    break;
                case 9:
                    System.out.printf("O valor critico de 234 - 255 é: %.2f\n", valorcritico[i]);
                    break;
                default:
                    break;
            }
        }
    }
}
