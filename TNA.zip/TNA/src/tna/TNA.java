package tna;

//import javax.swing.JFrame;
//import javax.swing.JOptionPane;

public class TNA {

    public static void main(String[] args) {

        Testes testes = new Testes();
        
        
        testes.construtorTestes();
        System.out.println(testes.calculaChiQuadrado());
        testes.calculaKS();
        
        //

        System.exit(0);
    }
}
