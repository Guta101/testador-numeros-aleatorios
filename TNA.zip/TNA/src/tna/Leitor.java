package tna;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

public class Leitor {
    
//Busca a string de números diretamente no site do gerador
    public static String leitura() throws IOException, InterruptedException {
        
        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create("https://qrng.anu.edu.au/API/jsonI.php?length=1024&type=uint8"))
                .GET()
                .build();
        
        HttpResponse<String> response = client.send(request,
                HttpResponse.BodyHandlers.ofString());
        
        String entradaSeparada = response.body().substring(response.body().indexOf("[") + 1, response.body().indexOf("]"));
        return entradaSeparada;
    }
}
